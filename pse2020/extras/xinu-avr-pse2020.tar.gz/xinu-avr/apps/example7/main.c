/* ex2.c - main, sndA, sndB */

#include <xinu.h>

void	send_a(void), led(void), led_placa(void);


/*------------------------------------------------------------------------
 * main  --  example of creating 3 concurrent processes in Xinu
 *------------------------------------------------------------------------
 */
void	main(void)
{
	resume( create(send_a, 128, 20, "process 1", 0) );
	resume( create(led, 128, 20, "process 2", 0) );
	resume( create(led_placa, 128, 20, "process 3", 0) );
}

/*------------------------------------------------------------------------
 * process 1: repeatedly emit 'A' on the console without terminating
 *------------------------------------------------------------------------
 */
void	send_a(void)
{
	while (1) {			/* infinite loop in process 1 */
		putc(CONSOLE, 'A');
	}
}

/*------------------------------------------------------------------------
 * process 2: -- parpadear les pb4 (pin 12) cada 400 ms infinitamente
 *------------------------------------------------------------------------
 */
void	led(void)
{
	while (1) {			/* infinite loop in process 2 */
		gpio_arduino_write(12, 1);
		sleepms(400);
		gpio_arduino_write(12, 0);
		sleepms(400);
	}
}

/*------------------------------------------------------------------------
 * process 3: parpadear led de la placa cada 1 segundo infinitamente
 *------------------------------------------------------------------------
 */
void	led_placa(void)
{
	while (1) {			/* infinite loop in process 3 */
		gpio_arduino_write(13, 1);
		sleep(1);
		gpio_arduino_write(13, 0);
		sleep(1);
	}
}





