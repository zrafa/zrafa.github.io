/* ex5.c - main, prod2, cons2 */

#include <xinu.h>

#include "adc.h"

void led(void);
void motor(void);
void reporte(void);


/* semaforos */
sid32	emergencia_s;
sid32	reporte_s;
sid32	fin_motor_s;

/*------------------------------------------------------------------------
 *  main  --  producer and consumer processes synchronized with semaphores
 *------------------------------------------------------------------------
 */
void	main(void)
{

	int i;
	int adc_val = 0;

	adc_init();


	/* semaforos */
	emergencia_s = semcreate(0);
	reporte_s = semcreate(0);
	fin_motor_s = semcreate(0);

	/* Creamos 3 tareas */
	resume( create(led, 64, 20, "led", 2, NULL, NULL) );
	resume( create(reporte, 128, 20, "reporte", 2, NULL, NULL) );
	resume( create(motor, 300, 20, "motor", 2, NULL, NULL) );


	/* main es ahora una tarea periódica que lee el sensor */
	for (;;) {

		for (i=0;i<100;i++) {
                	adc_val = adc_get(0);
			printf("adc: %i\n", adc_val);
			sleepms(10);
		}

		if ( (adc_val < 300) || (adc_val > 700) ) {
			signal(emergencia_s);
			signal(reporte_s);
		
			wait(fin_motor_s);
		}

        }
	
}

/* led testigo : tarea periódica */
void	led(void)
{
	while (1) {

		sleepms(300);
		gpio_arduino_write(12, 1);

		sleepms(300);
		gpio_arduino_write(12, 0);

	}
}


/* motor que controla la planta: tarea que espera un evento */
void motor(void)
{

	for (;;) {
		wait(emergencia_s);

		/* encendemos motor */
		gpio_arduino_write(10, 1);
		sleep(5);

		/* stop motor */
		gpio_arduino_write(10, 0);
		sleep(20);
		
		signal(fin_motor_s);
	}

}

/* luz de emergencia: tarea que espera un evento */
void reporte(void)
{
	for (;;) {
		wait(reporte_s);

		/* luz de aviso de emergencia */
		gpio_arduino_write(9, 1);
		sleep(3);

		gpio_arduino_write(9, 0);
		sleep(1);
	}


}
