/* avr specific */

typedef unsigned int size_t;
#include <avr/pgmspace.h>

// extern const char CONSOLE_RESET[];
// extern const char m0[];
extern const char sysinit_m0[];
extern const char sysinit_m1[];
extern const char sysinit_m2[];
extern const char sysinit_m3[];
extern const char m00[];
extern const char m000[];
extern const char m1[];
extern const char m2[];
extern const char m3[];
extern const char m4[];
extern const char m5[];
extern const char m6[];
extern const char m7[];
extern const char m8[];
extern const char m9[];
extern const char m10[];
extern const char m11[];
extern const char m12[];
extern const char m13[];






