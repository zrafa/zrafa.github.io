/* ctype_.c - _ctype_ */

#include	<ctype.h>

/*------------------------------------------------------------------------
 *  _ctype_  -  Provides _ctype_.
 *------------------------------------------------------------------------
 */
#include <avr/io.h>
typedef unsigned int size_t;
#include <avr/pgmspace.h>
const char _ctype_[] PROGMEM = {
    0,
    _C, _C, _C, _C, _C, _C, _C, _C,
    _C, _S, _S, _S, _S, _S, _C, _C,
    _C, _C, _C, _C, _C, _C, _C, _C,
    _C, _C, _C, _C, _C, _C, _C, _C,
    _S, _P, _P, _P, _P, _P, _P, _P,
    _P, _P, _P, _P, _P, _P, _P, _P,
    _N, _N, _N, _N, _N, _N, _N, _N,
    _N, _N, _P, _P, _P, _P, _P, _P,
    _P, _U | _X, _U | _X, _U | _X, _U | _X, _U | _X, _U | _X,
    _U,
    _U, _U, _U, _U, _U, _U, _U, _U,
    _U, _U, _U, _U, _U, _U, _U, _U,
    _U, _U, _U, _P, _P, _P, _P, _P,
    _P, _L | _X, _L | _X, _L | _X, _L | _X, _L | _X, _L | _X,
    _L,
    _L, _L, _L, _L, _L, _L, _L, _L,
    _L, _L, _L, _L, _L, _L, _L, _L,
    _L, _L, _L, _P, _P, _P, _P, _C
};
