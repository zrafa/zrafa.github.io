/* avr_eepfs_write.c  -  avr_eepfs_write */

#include <xinu.h>
#include <avr_eepfs.h>

/*------------------------------------------------------------------------
 * avr_eepfs_write  -  Write a block to a file in avr_eepfs file system
 *------------------------------------------------------------------------
 */
devcall	avr_eepfs_write (
	  const __flash struct dentry	*devptr,	/* Entry in device switch table	*/
	  char	*buff,			/* Buffer containing a block	*/
	  int32	blk			/* Block number to write	*/
	)
{
	int32	bpos;			/* Byte position of blk		*/

	bpos = RM_BLKSIZ * blk;
	// memcpy(&Ram.disk[bpos], buff, RM_BLKSIZ);
	kprintf("b:%s\n",buff);
	kprintf("b1:%s\n",blk);
	eeprom_write_block((void *)buff, (const void *)0, blk);
	return OK;
}
