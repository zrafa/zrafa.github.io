/* avr_eepfs_open.c  -  avr_eepfs_open */

#include <xinu.h>


#define EEPFS_NAME_LEN 8
#define EEPFS_BLOCK_SIZE 32
#define EEPFS_FILES_BLKS_START 7	/* byte offset in meta data of meta files blocks */

/*------------------------------------------------------------------------
 * avr_eepfs_open  -  Open a file in the avr_eepfs file system
 *------------------------------------------------------------------------
 */

devcall	avr_eepfs_open (
	 const __flash struct	dentry	*devptr,	/* Entry in device switch table	*/
	 char	*name,			/* Unused for a avr_eepfs_ disk	*/
	 char	*mode			/* Unused for a avr_eepfs_ disk	*/
	)
{

	char buf[32];
	char *from, *to;
	/* Check length of name file (leaving space for NULLCH */

	from = name;
	for (i=0; i< EEPFS_NAME_LEN; i++) {
		if (*from++ == NULLCH) {
			break;
		}
	}
	if (i >= EEPFS_NAME_LEN) {		/* Name is too long */
		return SYSERR;
	}

	/* read meta data of file system */
	eeprom_seek(NULL, 0);
	eeprom_read(NULL, buff, 32);


	char eep_name[8];
	int not_found = 1;
	/* check if the name exists */
	for (i=EEPFS_FILES_BLKS_START; i<EEPFS_BLOCK_SIZE; i++)
		if (buf[i] == 0) {
			break;
		}
		eeprom_read(NULL, eep_name, 8);
		if ((strncmp(eep_name, name, 8)) == 0) {
			not_found = 1;
			break;
		}
		while ((i<EEPFS_BLOCK_SIZE) && (buf[i] & (1<<8) == 0))


	//RAFA
		kprintf("eou:%i\n",devptr->dvnum);
	return devptr->dvnum;
}
