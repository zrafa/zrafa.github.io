/* avr_eepfs_close.c  -  avr_eepfs_close */

#include <xinu.h>

/*------------------------------------------------------------------------
 * avr_eepfs_close  -  Close a file in the file system
 *------------------------------------------------------------------------
 */
devcall	avr_eepfs_close (
	 const __flash struct dentry	*devptr		/* Entry in device switch table	*/
	)
{
	return OK;
}
