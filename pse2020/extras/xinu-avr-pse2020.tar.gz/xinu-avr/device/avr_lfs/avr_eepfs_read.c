/* avr_eepfs_read.c  -  avr_eepfs_read */

#include <xinu.h>
#include <avr_eepfs.h>

/*------------------------------------------------------------------------
 * avr_eepfs_read  -  Read a block from a file in the file system
 *------------------------------------------------------------------------
 */
devcall	avr_eepfs_read (
	  const __flash struct dentry	*devptr,	/* Entry in device switch table	*/
	  char	*buff,			/* Buffer to hold disk block	*/
	  int32	blk			/* Block number of block to read*/
	)
{
	int32	bpos;			/* Byte position of blk		*/

	bpos = RM_BLKSIZ * blk;
	// memcpy(buff, &Ram.disk[bpos], RM_BLKSIZ);
	eeprom_read_block((void *)buff, (const void*)0, blk);
	return OK;
}
