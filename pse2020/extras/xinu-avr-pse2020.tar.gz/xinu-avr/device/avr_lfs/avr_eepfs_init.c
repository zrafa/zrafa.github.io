/* avr_eepfs_init.c  -  avr_eepfs_init */

#include <xinu.h>
#include <avr_eepfs.h>

// struct	avr_eepfs_disk	Ram;

/*------------------------------------------------------------------------
 *  avr_eepfs_init  -  Initialize the avr_eepfs file system
 *------------------------------------------------------------------------
 */
devcall	avr_eepfs_init (
	  const __flash struct dentry	*devptr		/* Entry in device switch table	*/
	)
{

	unsigned char buf[32];

	buf[0] = 32;
	buf[1] = 32;

	eeprom_seek(NULL, 0);
//	eeprom_read(NULL, buf, 32);
	eeprom_write(NULL, buf, 32);

	
	return OK;
}
